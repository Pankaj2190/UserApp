import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { SaveModel } from '../model/saveModel';


@Injectable()
export class HttpService {

  private options = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  constructor(private httpClient: HttpClient) { }

  getData<T>(url: string): Observable<T> {
    return this.httpClient.get<T>(environment.APIUrl + url);
  }

  getDataById<T>(url: string): Observable<T> {
    return this.httpClient.get<T>(environment.APIUrl + url);
  }

  saveData<T>(url: string, data: FormData): Observable<T> {
    return this.httpClient.post<T>(environment.APIUrl + url, data, this.options);
  }

  updateData<T>(url: string, data: FormData): Observable<T> {
    return this.httpClient.put<T>(environment.APIUrl + url, data, this.options);
  }

  deleteData<T>(url: string): Observable<T> {
    return this.httpClient.delete<T>(environment.APIUrl + url);
  }

}
