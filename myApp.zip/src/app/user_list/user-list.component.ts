import { Component, OnInit } from '@angular/core';
import { UserModel, UserViewModel } from '../model/userModel';
import { UserService } from '../service/user.service';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user_list',
  templateUrl: './user_list.component.html',
  styleUrls: ['./user_list.component.css']
})

export class UserListComponent implements OnInit {

  // It maintains list of users
  userList: UserModel[];

  //It maintains Subscription
  private allSubscription = new Subscription();

  //It maintains paging
  page: number = 1;
  per_page: number = 3;
  total: number = 12;
  total_pages: number = 4;
  from: number;
  to: number;

  constructor(private userService: UserService, private router: Router) {
    this.GetUserData(1);
  }

  ngOnInit() { }

  //this method used to get user data
  GetUserData(page) {
    if (page <= 0) {
      page = 1;
    }
    if (this.to == this.total) {
      page = page - 1;
    }

    const subscription = this.userService.getUser(page).subscribe(
      users => {
        this.userList = users.data;
        this.page = users.page;
        this.per_page = users.per_page;
        this.total = users.total;
        this.total_pages = users.total_pages;
        if (this.page == 1) {
          this.from = 1;
          this.to = this.from + this.per_page - 1;
        }
        else {
          this.from = (page - 1) * this.per_page + 1;
          this.to = this.from + this.per_page - 1;
        }
      },
      error => {
        console.log(error);
      });
    this.allSubscription.add(subscription);
  }

  // This method takes us to add user
  onNew() {
    this.router.navigate(['/useradd', 0]);
  }

  // This method takes us to edit user
  onEdit(id: number) {
    this.router.navigate(['/useradd', id]);
  }

  // This method takes us to user detail
  onDetail(id: number) {
    this.router.navigate(['/userdetail', id]);
  }

  // This method associate to Delete Button.
  onDelete(id: number) {
    if (confirm("Are you sure to delete ?")) {
      const subscription = this.userService.deleteUser(id).subscribe(
        users => {
          if (users) {
            alert("Record successfully deleted");
          }
          else {
            alert("Delete api is not working. Please try again later");
          }
        },
        error => {
          console.log(error);
        });
      this.allSubscription.add(subscription);
    }
  }
}
