export class SaveModel {
    public name: string;
    public job: string;
}