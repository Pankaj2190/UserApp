import { Component, OnInit } from '@angular/core';
import { UserModel } from '../model/userModel';
import { UserService } from '../service/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user_detail',
  templateUrl: './user_detail.component.html',
  styleUrls: ['./user_detail.component.css']
})

export class UserDetailComponent implements OnInit {

  // It maintains user Model
  userModel: UserModel;

  // It maintains Subscription
  private allSubscription = new Subscription();

  //Get route data
  id: number;
  private sub: any;

  constructor(private userService: UserService,
    private route: ActivatedRoute,
    private router: Router) {
  }

  ngOnInit() {
    //get route data
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id'];
    });

    this.getDetail();
  }

  //It is used to get user detail
  getDetail() {
    const subscription = this.userService.getUserbyId(this.id).subscribe(
      users => {
        this.userModel = users.data;
      },
      error => {
        console.log(error);
      });
    this.allSubscription.add(subscription);
  }

  // This takes us to list
  onList() {
    this.router.navigate(['/userlist']);
  }

}
