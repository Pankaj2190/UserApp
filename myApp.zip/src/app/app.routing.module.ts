import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { UserListComponent } from './user_list/user-list.component';
import { UserDetailComponent } from './user_detail/user-detail.component';
import { UserAddComponent } from './user_add/user-add.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'userlist',
    component: UserListComponent
  },
  {
    path: 'useradd/:id',
    component: UserAddComponent
  },
  {
    path: 'userdetail/:id',
    component: UserDetailComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
