import { Injectable, OnInit } from '@angular/core'
import { UserModel, UserViewModel } from '../model/userModel';
import { SaveStatus } from '../model/saveStatus';
import { HttpService } from './http.service';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SaveModel } from '../model/saveModel';


@Injectable()
export class UserService implements OnInit {

    userList: UserViewModel;
    userModel: UserModel;
    saveStatus: SaveStatus;
    saveModel: SaveModel;

    constructor(private httpService: HttpService) { }

    ngOnInit() { }

    getUser(page: number) {
        return this.httpService.getData<UserViewModel>("/users?page=" + page).pipe(
            catchError(this.handleError));
    }

    getUserbyId(id: number) {
        return this.httpService.getDataById<UserModel>("/users/" + id).pipe(
            catchError(this.handleError));
    }

    deleteUser(id: number) {
        return this.httpService.deleteData<boolean>("/users/" + id).pipe(
            catchError(this.handleError));
    }

    saveUser(formdata: FormData) {
        return this.httpService.saveData<SaveStatus>("/users/", formdata).pipe(
            catchError(this.handleError));
    }

    updateUser(formdata: FormData, id: number) {
        return this.httpService.updateData<SaveStatus>("/users/" + id, formdata).pipe(
            catchError(this.handleError));
    }

    private handleError(err: HttpErrorResponse) {
        console.log(err.message);
        return Observable.throw(err.message);
    }

}