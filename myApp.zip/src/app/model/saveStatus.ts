export class SaveStatus {
    public name: string;
    public job: string;
    public id: number;
    public createdAt: string;
    public updatedAt: string
}