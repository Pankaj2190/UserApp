import { Component, OnInit } from '@angular/core';
import { UserModel } from '../model/userModel';
import { UserService } from '../service/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user_add',
  templateUrl: './user_add.component.html',
  styleUrls: ['./user_add.component.css']
})

export class UserAddComponent implements OnInit {

  // It maintains user Model
  userModel: UserModel;

  //it maintains subscription
  private allSubscription = new Subscription();

  // It will be either 'Save' or 'Update' based on operation.
  submitType: string = 'Save';

  // It maintains file uploaded
  selectedFile: File = null;

  //Sets selected file path
  selectedFilePath: string = "";

  //route variable
  id: number;
  private sub: any;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) {
  }

  ngOnInit() {
    //It is used to get route values
    this.sub = this.route.params.subscribe(params => {
      this.id = +params['id'];
    });

    if (this.id == 0) {
      this.onNew();
    }
    else {
      this.onEdit();
    }
  }

  // This method associate to New Button.
  onNew() {
    // Initiate new user.
    this.userModel = new UserModel();

    // Change submitType to 'Save'.
    this.submitType = 'Save';
  }

  // This method associate to Edit Button.
  onEdit() {
    const subscription = this.userService.getUserbyId(this.id).subscribe(
      users => {
        this.userModel = users.data;
        this.selectedFilePath = this.userModel.avatar;
      },
      error => {
        console.log(error);
      });
    this.allSubscription.add(subscription);

    // Change submitType to Update.
    this.submitType = 'Update';
  }

  // This method associate to Save Button.
  onSave() {
    const formData = new FormData();
    formData.append('name', this.userModel.first_name + " " + this.userModel.last_name);
    formData.append('job', "Test Job");

    alert("Cors are not enable.Please try again later");

    // if (this.submitType === 'Save') {
    //   // save the use data
    //   const subscription = this.userService.saveUser(formData).subscribe(
    //     users => {
    //       alert("Data saved successfully");
    //       this.router.navigate(['/userlist']);
    //     },
    //     error => {
    //       console.log(error);
    //     });
    //   this.allSubscription.add(subscription);
    // }
    // else {
    //   // Update the existing user data
    //   const subscription = this.userService.updateUser(formData, this.userModel.id).subscribe(
    //     users => {
    //       alert("Data updated successfully");
    //       this.router.navigate(['/userlist']);
    //     },
    //     error => {
    //       console.log(error);
    //     });
    //   this.allSubscription.add(subscription);
    // }
  }

  // This method associate toCancel Button.
  onCancel() {
    this.router.navigate(['/userlist']);
  }

  //this mehod handles file upload data
  onFileSelected(event) {
    this.selectedFile = <File>event.target.files[0];

    const reader: FileReader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event: Event) => {
      this.selectedFilePath = reader.result;
    };

  }

}
