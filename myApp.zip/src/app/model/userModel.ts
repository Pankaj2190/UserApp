export class UserModel {
    public id: number = 0;
    public first_name: string = "";
    public last_name: string = "";
    public email: string = "";
    public avatar: string = "";
}

export class UserViewModel {
    public page: number;
    public per_page: number;
    public total: number;
    public total_pages: number;
    public data: UserModel[];
}